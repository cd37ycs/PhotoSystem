﻿using System;
using System.Web;
using System.Data;
using System.Linq;
using System.Web.Mvc;
using PhotoSystem.Models;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace PhotoSystem.Controllers
{
    public class HomeController : Controller
    {
        DALMethod myDAL = new DALMethod();

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetCarousel()//查询轮播图片
        {
            #region SQL查询方法
            SqlParameter[] sql =
            {
                new SqlParameter("@Type",SqlDbType.NChar),
            };
            sql[0].Value = "_GetCarousel";
            DataTable dt = myDAL.QueryDataTable("Home_Manage", sql);
            #endregion
            string CarouselHtml = "";//存轮播数据
            foreach (DataRow dr in dt.Rows)
            {
                string PhotoName = dr["PhotoName"].ToString();//名称
                string PhotoBewrite = dr["PhotoBewrite"].ToString();//简介
                string PhotoUrl = dr["PhotoUrl"].ToString();//路径
                CarouselHtml += "<div><img class='center-block' src='/PhotoData/" + PhotoUrl + "'></div>";
            }
            return Json(CarouselHtml, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetPhotoData(string Page, string PageSize)//查询图片
        {
            if (Page == "" || PageSize == ""|| Page.Contains("-")|| Page.Contains("0")) { return Json(false, JsonRequestBehavior.AllowGet); }

            #region SQL查询方法
            SqlParameter[] sql =
            {
                new SqlParameter("@Type",SqlDbType.NChar),
                new SqlParameter("@Page",SqlDbType.NChar),
                new SqlParameter("@PageSize",SqlDbType.NChar),
            };
            sql[0].Value = "_GetPhoto";
            sql[1].Value = Page;
            sql[2].Value = PageSize;
            DataTable dt = myDAL.QueryDataTable("Home_Manage", sql);
            #endregion
            string PhotoHtml = "";//存轮图片数据
            foreach (DataRow dr in dt.Rows)
            {
                string PhotoName = dr["PhotoName"].ToString();//名称
                string PhotoBewrite = dr["PhotoBewrite"].ToString();//简介
                string PhotoUrl = dr["PhotoUrl"].ToString();//路径
                string tbCount = dr["tbCount"].ToString();//总行数
                PhotoHtml += "<div class='col-xs-12 col-sm-6 col-md-3'><div class='zg-main-image' style='background-image: url(/PhotoData/" + PhotoUrl + ");' data-image='/PhotoData/" + PhotoUrl + "' data-title='" + PhotoName + "' data-caption='" + PhotoBewrite + "'></div></div>";
            }
            return Json(PhotoHtml, JsonRequestBehavior.AllowGet);
        }
    }
}