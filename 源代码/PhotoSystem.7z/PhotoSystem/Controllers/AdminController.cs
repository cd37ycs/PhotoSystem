﻿using System;
using System.IO;
using System.Web;
using System.Data;
using System.Linq;
using System.Web.Mvc;
using PhotoSystem.Models;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace PhotoSystem.Controllers
{
    public class AdminController : Controller
    {
        DALMethod myDAL = new DALMethod();

        public ActionResult Index()//后台登录页面
        {
            #region 读取Session数据
            string Account = "";//账号
            string Password = "";//密码
            if (Session["UserID"] != null)
            {
                Account = Session["Account"].ToString();
                Password = Session["Password"].ToString();
            }
            ViewData["Account"] = Account;
            ViewData["Password"] = Password;
            #endregion
            return View();
        }
        public ActionResult Main()//后台管理页面
        {
            string UserID = ""; try { UserID = Session["UserID"].ToString(); } catch { return View("Index"); }
            return View();
        }
        public ActionResult SubpagePhotoData()//预览的图片
        {
            string UserID = ""; try { UserID = Session["UserID"].ToString(); } catch { return View("Index"); }
            return View();
        }
        public ActionResult SubpageCarousel()//轮播的图片
        {
            string UserID = ""; try { UserID = Session["UserID"].ToString(); } catch { return View("Index"); }
            return View();
        }
        public ActionResult SubpageUserCenter()//个人中心
        {
            string UserID = ""; try { UserID = Session["UserID"].ToString(); } catch { return View("Index"); }

            return View();
        }
        /// <summary>
        /// 查询所有图片
        /// </summary>
        /// <param name="Page">页码</param>
        /// <param name="PageSize">每页数量</param>
        /// <param name="QueryLikeStr">模糊搜索内容</param>
        /// <returns></returns>
        public ActionResult View_GetPhotoData(string Page, string PageSize, string QueryLikeStr)
        {
            List<Dictionary<string, object>> ListReturn = new List<Dictionary<string, object>>();
            try
            {
                #region SQL查询方法
                SqlParameter[] sql =
                {
                    new SqlParameter("@Type",SqlDbType.NChar),
                    new SqlParameter("@Page",SqlDbType.NChar),
                    new SqlParameter("@PageSize",SqlDbType.NChar),
                    new SqlParameter("@QueryLikeStr",SqlDbType.NChar),
                };
                sql[0].Value = "View_GetPhotoData";
                sql[1].Value = Page;
                sql[2].Value = PageSize;
                sql[3].Value = QueryLikeStr;
                ListReturn = myDAL.QueryList("Admin_Manage", sql);
                var total = "0";
                if (ListReturn.Count != 0) total = ListReturn[0]["tbCount"].ToString();//获取总数
                #endregion
                return Json(new { total = total, rows = ListReturn }, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 登录验证
        /// </summary>
        /// <param name="Account">账号</param>
        /// <param name="Password">密码</param>
        /// <returns></returns>
        public ActionResult Login(string Account, string Password)
        {
            if (Account != "" || Password != "")
            {
                string Passwords = MD5Method.GetMd5(Password).ToUpper();//MD5加密

                #region SQL查询方法
                SqlParameter[] sql =
                {
                    new SqlParameter("@Type",SqlDbType.NChar),
                    new SqlParameter("@Account",SqlDbType.NChar),
                    new SqlParameter("@Password",SqlDbType.NChar),
                };
                sql[0].Value = "Verifylogin";
                sql[1].Value = Account;
                sql[2].Value = Passwords;
                DataTable dt = myDAL.QueryDataTable("Admin_Manage", sql);
                #endregion

                if (dt.Rows.Count == 1)
                {
                    Session["Account"] = Account;
                    Session["Password"] = Password;
                    Session["UserID"] = dt.Rows[0]["UserID"].ToString();
                    return Json(true, JsonRequestBehavior.AllowGet);
                }
            }
            return Json(false, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 修改用户数据
        /// </summary>
        /// <param name="Account">账号</param>
        /// <param name="Password">密码</param>
        /// <returns></returns>
        public ActionResult ModifyUser(string Account, string Password)
        {
            string UserID = "";
            try
            {
                UserID = Session["UserID"].ToString();
                if (Account != "" || Password != "")
                {
                    string Passwords = MD5Method.GetMd5(Password).ToUpper();//MD5加密
                    
                    SqlParameter[] sql =
                    {
                        new SqlParameter("@Type",SqlDbType.NChar),
                        new SqlParameter("@UserID",SqlDbType.NChar),
                        new SqlParameter("@Account",SqlDbType.NChar),
                        new SqlParameter("@Password",SqlDbType.NChar),
                    };
                    sql[0].Value = "ModifyUser";
                    sql[1].Value = UserID;
                    sql[2].Value = Account;
                    sql[3].Value = Passwords;
                    int i = myDAL.UpdateData("Admin_Manage", sql);
                    if (i > 0) return Json(true, JsonRequestBehavior.AllowGet);
                }
            }
            catch { }
            return Json(false, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 新增图片
        /// </summary>
        /// <param name="file">文件数据</param>
        /// <param name="PhotoName">图片名称</param>
        /// <param name="PhotoBewrite">图片描述</param>
        /// <param name="PhotoUrl">图片地址</param>
        /// <returns></returns>
        public ActionResult Insert_Photo(HttpPostedFileBase file, string PhotoName, string PhotoBewrite)
        {
            string UserID = "";
            try
            {
                UserID = Session["UserID"].ToString();
                if (PhotoName != "" && PhotoBewrite != "")
                {
                    #region 上传文件
                    string fileExtension = Path.GetExtension(file.FileName);//文件类型
                    if (fileExtension.Contains("jpg") || fileExtension.Contains("png"))
                    {
                        string DirDate = Server.MapPath("~/PhotoData/" + DateTime.Now.ToString("yyyyMMdd"));
                        if (!Directory.Exists(DirDate)) Directory.CreateDirectory(DirDate);
                        string filePath = DirDate + "/" + file.FileName;//保存文件的路径
                        file.SaveAs(filePath);//保存文件
                        string PhotoUrl = DateTime.Now.ToString("yyyyMMdd") + "/" + file.FileName;//图片地址
                        #endregion

                        #region 新增到数据库
                        SqlParameter[] sql =
                        {
                            new SqlParameter("@Type",SqlDbType.NChar),
                            new SqlParameter("@PhotoName",SqlDbType.NChar),
                            new SqlParameter("@PhotoBewrite",SqlDbType.NChar),
                            new SqlParameter("@PhotoUrl",SqlDbType.NChar),
                        };
                        sql[0].Value = "Insert_Photo";
                        sql[1].Value = PhotoName;
                        sql[2].Value = PhotoBewrite;
                        sql[3].Value = PhotoUrl;
                        int i = myDAL.UpdateData("Admin_Manage", sql);
                        #endregion
                        if (i > 0) return Json(true, JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch { }
            return Json(false, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 修改图片
        /// </summary>
        /// <param name="PhotoName">图片名称</param>
        /// <param name="PhotoBewrite">图片描述</param>
        /// <param name="PhotoID">图片ID</param>
        /// <returns></returns>
        public ActionResult Update_Photo(string PhotoName, string PhotoBewrite, string PhotoID)
        {
            string UserID = "";
            try
            {
                UserID = Session["UserID"].ToString();
                if (PhotoID != "" && PhotoName != "" && PhotoBewrite != "")
                {
                    SqlParameter[] sql =
                    {
                        new SqlParameter("@Type",SqlDbType.NChar),
                        new SqlParameter("@PhotoName",SqlDbType.NChar),
                        new SqlParameter("@PhotoBewrite",SqlDbType.NChar),
                        new SqlParameter("@PhotoID",SqlDbType.NChar),
                    };
                    sql[0].Value = "Update_Photo";
                    sql[1].Value = PhotoName;
                    sql[2].Value = PhotoBewrite;
                    sql[3].Value = PhotoID;
                    int i = myDAL.UpdateData("Admin_Manage", sql);
                    if (i > 0) return Json(true, JsonRequestBehavior.AllowGet);
                }
            }
            catch { }
            return Json(false, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 删除图片
        /// </summary>
        /// <param name="PhotoID">图片ID</param>
        /// <returns></returns>
        public ActionResult Delete_Photo(string PhotoID)
        {
            string UserID = "";
            try
            {
                UserID = Session["UserID"].ToString();
                if (PhotoID != "")
                {
                    SqlParameter[] sql =
                    {
                        new SqlParameter("@Type",SqlDbType.NChar),
                        new SqlParameter("@PhotoID",SqlDbType.NChar),
                    };
                    sql[0].Value = "Delete_Photo";
                    sql[1].Value = PhotoID;
                    int i = myDAL.UpdateData("Admin_Manage", sql);
                    if (i > 0) return Json(true, JsonRequestBehavior.AllowGet);
                }
            }
            catch { }
            return Json(false, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 修改显示轮播状态
        /// </summary>
        /// <param name="PhotoID">图片ID</param>
        /// <returns></returns>
        public ActionResult Update_Carousel(string PhotoID)
        {
            string UserID = "";
            try
            {
                UserID = Session["UserID"].ToString();
                if (PhotoID != "")
                {
                    SqlParameter[] sql =
                    {
                        new SqlParameter("@Type",SqlDbType.NChar),
                        new SqlParameter("@PhotoID",SqlDbType.NChar),
                    };
                    sql[0].Value = "Update_Carousel";
                    sql[1].Value = PhotoID;
                    int i = myDAL.UpdateData("Admin_Manage", sql);
                    if (i > 0) return Json(true, JsonRequestBehavior.AllowGet);
                }
            }
            catch { }
            return Json(false, JsonRequestBehavior.AllowGet);
        }
    }
}