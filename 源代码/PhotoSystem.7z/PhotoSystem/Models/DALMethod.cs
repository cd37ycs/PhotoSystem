using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Configuration;

namespace PhotoSystem.Models
{
    public class DALMethod
    {
        #region 连接字符串
        //string strConnect = @"Data Source=(local);Initial Catalog=PhotoManagement;User ID=sa;Password=123";
        string strConnect = ConfigurationManager.AppSettings["strConnect"];
        #endregion

        #region 查询数据表
        public DataTable QueryDataTable(String sql, SqlParameter[] param)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(strConnect))
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.AddRange(param);
                da.Fill(dt);
                conn.Close();
            }
            return dt;
        }
        #endregion

        #region 查询数据表
        public List<Dictionary<string, object>> QueryList(String sql, SqlParameter[] param)
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(strConnect))
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                da.SelectCommand.Parameters.AddRange(param);
                da.Fill(dt);
                conn.Close();
            }
            return DtToList(dt);
        }
        #endregion

        #region 插入、更新、删除
        public int UpdateData(String sql, SqlParameter[] param)
        {
            int count = 0;
            using (SqlConnection conn = new SqlConnection(strConnect))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddRange(param);
                count = cmd.ExecuteNonQuery();
                conn.Close();
            }
            return count;
        }
        #endregion

        #region 二进制文件查询方法
        public byte[] QueryDataByte(String sql, SqlParameter[] param)
        {
            using (SqlConnection conn = new SqlConnection(strConnect))
            {
                conn.Open();//打开连接
                SqlDataReader dr = null;//初始化数据读取器  
                SqlCommand cmd = new SqlCommand(sql, conn);//创建命令对象
                cmd.CommandType = CommandType.StoredProcedure;//设置命令类型
                cmd.Parameters.AddRange(param);//把参数加进命令对象
                dr = cmd.ExecuteReader();//启动dr
                byte[] File = null;//初始化byte
                if (dr.Read())//执行把二进制流加进byte[]中
                {
                    File = (byte[])dr[0];
                }
                dr.Close();//关闭数据读取器
                conn.Close();//关闭连接
                return File;
            }
        }
        #endregion

        #region 把DataTable转换成List
        private List<Dictionary<string, object>> DtToList(DataTable dt)
        {
            List<Dictionary<string, object>> list = new List<Dictionary<string, object>>();
            foreach (DataRow dataRow in dt.Rows)
            {
                Dictionary<string, object> dictionary = new Dictionary<string, object>();
                foreach (DataColumn dataColumn in dt.Columns)
                {
                    dictionary.Add(dataColumn.ColumnName, dataRow[dataColumn.ColumnName]);
                }
                list.Add(dictionary);
            }
            return list;
        }
        #endregion
    }
}